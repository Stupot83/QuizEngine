module.exports = {
    mongoURI: "mongodb+srv://Stupot83:Corjb2021x@quizengine1.grwfs.mongodb.net/QuizEngine?retryWrites=true&w=majority",
    secretOrKey: "secret"
};
